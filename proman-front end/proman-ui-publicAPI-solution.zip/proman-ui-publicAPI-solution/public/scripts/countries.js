async function ready() {
    const url = 'https://u50g7n0cbj.execute-api.us-east-1.amazonaws.com/v2/countries?limit=200&page=1&offset=0&sort=asc&order_by=country';
    
    try {
        const rawResponse = await fetch(url);
        const result = await rawResponse.json();
        const countries = result.results;
        countries.forEach(({ name }) => {
            const template = `<div>${name}</div>`;
            const element = document.createElement('div');
            element.innerHTML = template;
            document.getElementsByClassName('country-ul')[0].append(element);
        })

    } catch(e) {
        alert(`Error: ${e.message}`);
    }
}

document.addEventListener("DOMContentLoaded", ready);